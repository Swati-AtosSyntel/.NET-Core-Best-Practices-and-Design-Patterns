﻿using System;

namespace SingleTon
{
    class A
    {
        private static A obj = new A();
        private A()
        {

        }
        public static A getA()
        {
            return obj;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
