﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClose
{
    class ColorSpecification:ISpecification<Product>
    {
        color color;

        public ColorSpecification(color color)
        {
            this.color = color;
        }

        public bool IsSatisFied(Product t)
        {
            return t.color1 == color;
        }
    }
}
