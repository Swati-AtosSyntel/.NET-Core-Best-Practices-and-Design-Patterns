﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClose
{
    class Product
    {
        public string name { get; set; }
        public color color1 { get; set; }
        public size size1 { get; set; }

        public Product(string name,color color1,size size1)
        {
            this.name = name;
            this.color1 = color1;
            this.size1 = size1;

        }
    }
}
