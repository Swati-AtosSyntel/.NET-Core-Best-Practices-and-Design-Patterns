﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClose
{
    class BetterFilter : IFilter<Product>
    {
        public IEnumerable<Product> Filter(IEnumerable<Product> items, ISpecification<Product> spec)
        {
            foreach (var i in items)
                if (spec.IsSatisFied(i))
                    yield return i;
        }
    }
}
