﻿using System;

namespace OpenClose
{
    public enum color { Red, Green, Blue };
    public enum size { small, Medium, Large };
    class Program
    {
        
        static void Main(string[] args)
        {
            var apple = new Product("Apple", color.Green, size.small);
            var tree = new Product("Tree", color.Green, size.Large);
            var house = new Product("House", color.Blue, size.Medium);

            Product[] products = { apple, tree, house };


            var bf = new BetterFilter();
            foreach(var p in bf.Filter(products,new ColorSpecification(color.Green)))
            {
                Console.WriteLine(p.name +"is green in color" );

            }
        }
    }
}
