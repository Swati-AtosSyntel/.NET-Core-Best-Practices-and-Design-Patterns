﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClose
{
    interface ISpecification<T>
    {
        bool IsSatisFied(T t);
    }

}
