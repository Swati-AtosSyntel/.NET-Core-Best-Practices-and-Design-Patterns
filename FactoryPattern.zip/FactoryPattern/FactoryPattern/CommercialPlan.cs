﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPattern
{
    class CommercialPlan : Plan
    {
        public override void GetRate()
        {
            rate = 8.50F;
        }
    }
}
