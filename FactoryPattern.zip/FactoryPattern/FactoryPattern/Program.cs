﻿using System;

namespace FactoryPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            GetPlanFactory planFactory = new GetPlanFactory();
            Console.WriteLine("Enter Name of Plan Domestic/Commercial");
            string planName = Console.ReadLine();
            Console.WriteLine("Enter number of units");

            int units = Convert.ToInt32(Console.ReadLine());

            Plan p = planFactory.GetPlan(planName);
            Console.WriteLine("Bill Amount for :"+planName +"of "+units+"units");

            p.GetRate();
            p.CalcBill(units);
        }
    }
}
