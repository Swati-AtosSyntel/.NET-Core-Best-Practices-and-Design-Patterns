﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPattern
{
    abstract class Plan
    {
        public float rate;
        public abstract void GetRate();

        public void CalcBill(int units)
        {
            Console.WriteLine(units*rate);
        }
    }
}
