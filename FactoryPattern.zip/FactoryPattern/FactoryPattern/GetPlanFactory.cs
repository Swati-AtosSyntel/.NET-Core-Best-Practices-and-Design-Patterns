﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPattern
{
    class GetPlanFactory
    {
        public Plan GetPlan(string planType)
        {
            if (planType == null)
                return null;
            else if (planType == "DomesticPlan")
            {
                return new DomesticPlan();
            }
            else if(planType=="CommercialPlan")
            {
                return new CommercialPlan();
            }
            return null;
        }
       
    }
}
