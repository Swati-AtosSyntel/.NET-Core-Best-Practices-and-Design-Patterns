﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPattern
{
    class DomesticPlan : Plan
    {
        public override void GetRate()
        {
            rate = 4.50F;
        }
    }
}
