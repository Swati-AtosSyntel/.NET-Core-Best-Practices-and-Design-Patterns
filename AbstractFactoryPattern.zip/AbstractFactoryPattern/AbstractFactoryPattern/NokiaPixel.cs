﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class NokiaPixel : ISmartPhone
    {
        public string GetMobileDetails()
        {
            return "Model: Nokia Pixel";
        }
    }
}
