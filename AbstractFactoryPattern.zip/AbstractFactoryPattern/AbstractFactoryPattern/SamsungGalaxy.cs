﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class SamsungGalaxy : ISmartPhone
    {
        public string GetMobileDetails()
        {
            return "SamsungGalaxy";
        }
    }
}
