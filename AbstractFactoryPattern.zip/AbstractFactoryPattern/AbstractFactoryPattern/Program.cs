﻿using System;

namespace AbstractFactoryPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IMobilePhone nokiaPhone = new Nokia();

            MobileClient nokiaClient = new MobileClient(nokiaPhone);

            Console.WriteLine(nokiaClient.GetNormalPhoneDetails());


            Console.WriteLine(nokiaClient.GetSmartPhoneModelDetails());
            Console.WriteLine("---------------------------------------\n");
            IMobilePhone SamsungPhone = new Samsung();
            MobileClient samsungClient = new MobileClient(SamsungPhone);
            Console.WriteLine(samsungClient.GetNormalPhoneDetails());
            Console.WriteLine(samsungClient.GetSmartPhoneModelDetails());

        }
    }
}
