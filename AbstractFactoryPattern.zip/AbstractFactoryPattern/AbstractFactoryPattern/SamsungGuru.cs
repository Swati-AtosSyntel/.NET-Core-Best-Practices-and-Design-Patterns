﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class SamsungGuru : INormalPhone
    {
        public string GetMobileDetails()
        {
            return "SamsungGuru Mobile";
        }
    }
}
