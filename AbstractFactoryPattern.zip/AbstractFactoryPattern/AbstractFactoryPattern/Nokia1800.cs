﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class Nokia1800 : INormalPhone
    {
        public string GetMobileDetails()
        {
            return "Nokia1800";
        }
    }
}
