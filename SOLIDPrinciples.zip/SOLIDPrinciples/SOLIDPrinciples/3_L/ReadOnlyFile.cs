﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._3_L
{
    class ReadOnlyFile:ILoad
    {
        public string Filepath { get; set; }
        public string FileText { get; set; }

        public string LoadText()
        {
            return "Read Only File";
        }
       
    }
}
