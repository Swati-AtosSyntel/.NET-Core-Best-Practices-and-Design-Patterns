﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._3_L
{
    class File
    {
        public string LoadText()
        {
            return string.Empty;
        }
        public void SaveText()
        {

        }
    }
}
