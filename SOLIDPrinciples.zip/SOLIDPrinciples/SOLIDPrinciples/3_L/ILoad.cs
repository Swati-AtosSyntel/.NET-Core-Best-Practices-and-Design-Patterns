﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._3_L
{
    interface ILoad
    {
        string LoadText();
    }
}
