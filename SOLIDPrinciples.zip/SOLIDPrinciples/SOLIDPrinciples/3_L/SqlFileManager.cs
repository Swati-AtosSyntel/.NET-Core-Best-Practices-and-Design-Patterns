﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._3_L
{
    class SqlFileManager
    {
        public List<ILoad> allFiles { get; set; }
        public List<IWrite> writeFiles { get; set; }

        public string GetTextFromFiles()
        {
            StringBuilder objStringBuilder = new StringBuilder();
            foreach(var objFile in allFiles)
            {
                objStringBuilder.Append(objFile.LoadText());
            }
            return objStringBuilder.ToString();
        }

        public void SaveTextIntoFiles()
        {
            foreach(var objFile in writeFiles)
            {

                objFile.SaveText();
            }
        }
    }
}
