﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._5_D
{
    class FileLogger:ILog
    {
        public void Log(string message)
        {
            Console.WriteLine("Inside Log method of FileLogger");
            
        }
        public void LogToFile(string message)
        {
            Console.WriteLine("Method:LogToFile,Text:{0}",message);
        }
    }
}
