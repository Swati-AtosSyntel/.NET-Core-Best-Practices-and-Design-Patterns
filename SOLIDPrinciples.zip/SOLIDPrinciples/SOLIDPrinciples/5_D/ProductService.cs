﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._5_D
{
    class ProductService
    {

        private readonly ILog logger;
        //private readonly FileLogger _fileLogger = new FileLogger();
        //private readonly DatabaseLogger _databaseLogger = new DatabaseLogger();

        //public void LogToFile(string message)
        //{
        //    _fileLogger.Log(message);
        //}
        //public void LogToDatabase(string message)
        //{
        //    _databaseLogger.Log(message);
        //}
        public ProductService(ILog log)
        {
            logger = log;
        }
        public void Log(string message)
        {
            logger.Log(message);
        }
    }
}
