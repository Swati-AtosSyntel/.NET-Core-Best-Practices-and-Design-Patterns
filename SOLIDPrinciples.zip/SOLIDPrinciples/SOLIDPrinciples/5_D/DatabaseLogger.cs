﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._5_D
{
    class DatabaseLogger:ILog
    {
        public void Log(string message)
        {
            Console.WriteLine("Inside Log method of Database Logger");
            
        }
        private void LogToDatabase(string message)
        {
            Console.WriteLine("Method:LogToDatabase,Text{0}",message);
        }
    }
}
