﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._5_D
{
    interface ILog
    {
        void Log(string message);
    }
}
