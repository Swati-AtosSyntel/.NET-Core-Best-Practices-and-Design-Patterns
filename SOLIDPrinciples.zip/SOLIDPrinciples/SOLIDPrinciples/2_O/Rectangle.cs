﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._2_O
{
    class Rectangle:IArea
    {
        public double Height { get; set; }
        public double Width { get; set; }

        public double Area()
        {
            return Height * Width;
        }
    }
}
