﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._2_O
{
    interface IArea
    {
        double Area();
    }
}
