﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._2_O
{
    class Circle:IArea
    {
        public double radius { get; set; }

        public double Area()
        {
            return radius * radius * Math.PI;
        }
    }
}
