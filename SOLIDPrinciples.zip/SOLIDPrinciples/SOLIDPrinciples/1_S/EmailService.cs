﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._1_S
{
    class EmailService
    {
        public bool validateEmail(string email)
        {
            return email.Contains("@");
        }
        public void SendEmail(User message) => Console.WriteLine("Send Message");
    }
}
