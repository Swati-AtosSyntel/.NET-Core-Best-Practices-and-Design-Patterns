﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._1_S
{
    class UserService
    {
        public void Register(string email,string password)
        {
            var emailService = new EmailService();
            if (!emailService.validateEmail(email))
                throw new Exception("Email is not valid");
            var user = new User(email, password);
            emailService.SendEmail(user);
        }
       
        public void Login(string email,string password)
        {
            Console.WriteLine("Login");
        }
       
    }
}
