﻿using SOLIDPrinciples._5_D;
using System;

namespace SOLIDPrinciples
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ILog objLog = new DatabaseLogger();
            var pdService = new ProductService(objLog);
            pdService.Log("Hello");
        }
    }
}
