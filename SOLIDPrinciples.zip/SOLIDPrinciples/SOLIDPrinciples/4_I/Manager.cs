﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._4_I
{
    class Manager : ICreate,IAssign
    {
        public void AssignTask()
        {
            
        }

        public void CreateTask()
        {

        }

      
    }
}
