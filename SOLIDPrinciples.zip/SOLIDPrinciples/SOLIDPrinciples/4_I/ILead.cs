﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._4_I
{
    interface ILead
    {
        void CreateTask();
        void AssignTask();
        void WorkOnTask();

    }
}
