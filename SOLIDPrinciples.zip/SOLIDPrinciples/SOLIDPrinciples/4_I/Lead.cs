﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._4_I
{
    class Lead : ILead
    {
        public void AssignTask()
        {
            
        }

        public void CreateTask()
        {
            
        }

        public void WorkOnTask()
        {
            
        }
    }
}
