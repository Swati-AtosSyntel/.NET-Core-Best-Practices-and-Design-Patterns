﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples._4_I
{
    interface IAssign
    {
        void AssignTask();
    }
}
