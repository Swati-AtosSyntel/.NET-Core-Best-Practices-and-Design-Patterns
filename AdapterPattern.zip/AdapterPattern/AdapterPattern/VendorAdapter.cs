﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdapterPattern
{
    class VendorAdapter : IProduct
    {
        public List<string> Getproducts()
        {
            Vendor v = new Vendor();
            return v.GetProducts();
        }
    }
}
