﻿using System;

namespace AdapterPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IProduct adapter = new VendorAdapter();
            foreach(string product in adapter.Getproducts())
            {
                Console.WriteLine(product);
            }
        }
    }
}
