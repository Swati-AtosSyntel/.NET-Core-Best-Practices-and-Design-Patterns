﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdapterPattern
{
    class Vendor
    {
        public List<string> GetProducts()
        {
            List<string> products = new List<string>()
            {
                "Gaming Headphone","Television","Books"
            };
            return products;

        }
    }
}

